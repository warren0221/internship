-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2021 at 11:26 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soits_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `contact` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `address`, `contact`) VALUES
(1, 'Company 1', 'Company 1', '+18456-5455-55'),
(2, 'Company 3', 'Company 1', '+18456-5455-55'),
(3, 'Company 3', 'Company 3', '8747808787'),
(7, 'asd', '2131', '123'),
(9, '55', 'ww', '11');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(30) NOT NULL,
  `course` varchar(200) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course`, `description`) VALUES
(1, 'Course 1', 'Course 1'),
(2, 'Course 2', 'Course 2'),
(3, 'Course 3', 'Course 3');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `contact` varchar(100) NOT NULL,
  `course_id` int(30) NOT NULL,
  `company_id` int(30) NOT NULL,
  `id_no` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `required_duration` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `address`, `contact`, `course_id`, `company_id`, `id_no`, `password`, `required_duration`) VALUES
(1, 'Warren Dela Cruz', 'Sample Address', '11111111111', 2, 1, '11111111', '80ee7ece5bdf991bc2ae95776f02568d', '505'),
(2, 'warrens', 'Sample only', '8747808787', 1, 1, '20140623', 'warren', '600'),
(9, 'wa', 'asd', '33333333333', 1, 1, '55555555', '202cb962ac59075b964b07152d234b70', '2'),
(10, '', '', '', 1, 0, '', '', ''),
(11, 'w', '', 'a', 103, 0, '5', '', ''),
(12, 'w', '', 'a', 103, 0, '44', '', ''),
(13, 'wa', 'asd', 'asd', 1, 0, '552', '', '5'),
(14, 's', '', 's', 1, 1, '51515', '', ''),
(15, 'asd', 'asd', '12312321321', 2, 3, '66222222', '', '50'),
(16, 'wa', 'ww', '11', 3, 1, '12222222', '80ee7ece5bdf991bc2ae95776f02568d', '50'),
(17, 'w', 'w', '11111111111', 2, 1, '11111110', 'c4ca4238a0b923820dcc509a6f75849b', '2'),
(18, 'Jhemaima Ann Fernando', 'Dyan lang sa tabi', '09123456789', 1, 8, '18500729', '6f2ad44768d2414e685f107a487893ad', '300'),
(19, 'asd', 's', '11111111111', 1, 1, '12312312', '80ee7ece5bdf991bc2ae95776f02568d', '3'),
(20, 'w', 'w', '11232211111', 1, 7, '21333221', '80ee7ece5bdf991bc2ae95776f02568d', '3'),
(21, 'w', 'w', '13213212122', 1, 7, '55555552', '80ee7ece5bdf991bc2ae95776f02568d', '3'),
(82, '', '', '', 3, 3, '55', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'Internship Management System', 'asd', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--

CREATE TABLE `timesheets` (
  `id` int(30) NOT NULL,
  `student_id` int(30) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `time_start` time NOT NULL DEFAULT current_timestamp(),
  `time_end` time NOT NULL,
  `remarks` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0= Unverified, 1=Verified',
  `timer_status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=timer started, 0 = timer ends',
  `stats` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timesheets`
--

INSERT INTO `timesheets` (`id`, `student_id`, `date`, `time_start`, `time_end`, `remarks`, `status`, `timer_status`, `stats`) VALUES
(1, 1, '2020-11-05', '10:00:00', '15:29:00', 'sample', 0, 0, ''),
(3, 1, '2020-11-05', '15:37:50', '15:37:00', 'sample \r\nsample', 0, 0, ''),
(4, 1, '2020-11-05', '15:48:35', '16:50:00', 'test 101', 0, 0, ''),
(5, 2, '2020-11-05', '08:05:00', '16:49:00', 'Sample Task', 0, 0, ''),
(6, 1, '2021-05-09', '15:02:03', '15:02:00', 'asd', 0, 0, ''),
(7, 1, '2021-05-09', '15:13:33', '15:13:00', 'we', 0, 0, ''),
(8, 1, '2021-05-09', '16:27:49', '16:27:00', '123', 0, 0, ''),
(9, 1, '2021-05-09', '16:27:58', '16:29:00', 's', 0, 0, ''),
(10, 1, '2021-05-10', '20:42:33', '00:00:00', '', 0, 1, ''),
(11, 1, '2021-05-11', '14:53:45', '14:53:00', 'asd', 0, 0, ''),
(12, 9, '2021-05-13', '13:33:58', '13:34:00', '4123ads', 0, 0, ''),
(13, 18, '2021-05-17', '13:57:40', '13:57:00', 'Nagkamot', 0, 0, ''),
(14, 18, '2021-05-17', '13:58:35', '13:59:00', 'Humikab', 0, 0, ''),
(15, 1, '2021-05-23', '13:31:53', '01:00:00', '', 0, 0, ''),
(16, 1, '2021-05-23', '13:33:02', '13:39:00', 'asd', 0, 0, ''),
(17, 1, '2021-05-23', '13:39:59', '13:40:00', '', 0, 0, ''),
(18, 1, '2021-05-23', '13:40:08', '13:44:00', '', 0, 0, ''),
(19, 0, '2021-05-23', '13:44:08', '00:00:00', '', 0, 1, ''),
(20, 0, '2021-05-23', '13:44:27', '00:00:00', '', 0, 1, ''),
(21, 0, '2021-05-23', '13:44:30', '00:00:00', '', 0, 1, ''),
(22, 1, '2021-05-23', '13:44:56', '13:45:00', '', 0, 0, ''),
(23, 1, '2021-05-23', '13:45:13', '13:45:00', '', 0, 0, ''),
(24, 0, '2021-05-23', '13:46:27', '00:00:00', '', 0, 1, ''),
(25, 0, '2021-05-23', '13:46:38', '00:00:00', '', 0, 1, ''),
(26, 0, '2021-05-23', '13:47:38', '00:00:00', '', 0, 1, ''),
(27, 1, '2021-05-23', '13:47:38', '13:47:00', '', 0, 0, ''),
(28, 1, '2021-05-23', '13:47:56', '13:48:00', '', 0, 0, ''),
(29, 1, '2021-05-23', '13:47:56', '13:48:00', '', 0, 0, ''),
(30, 1, '2021-05-23', '13:50:32', '01:00:00', '', 0, 0, ''),
(31, 1, '2021-05-23', '13:50:52', '13:51:00', '', 0, 0, ''),
(32, 0, '2021-05-23', '13:52:43', '00:00:00', '', 0, 1, ''),
(33, 1, '2021-05-23', '13:53:13', '01:00:00', '', 0, 0, ''),
(34, 1, '2021-05-23', '13:53:31', '13:53:00', '', 0, 0, ''),
(35, 1, '2021-05-23', '13:53:53', '13:54:00', '', 0, 0, ''),
(36, 1, '2021-05-23', '14:05:50', '14:05:00', 'asd', 0, 0, ''),
(37, 1, '2021-05-23', '14:06:52', '01:00:00', '', 0, 0, 'Offline'),
(38, 1, '2021-05-23', '14:07:49', '14:07:00', '', 0, 0, 'Offline'),
(39, 1, '2021-05-23', '14:08:59', '14:09:00', '', 0, 0, 'Offline'),
(40, 0, '2021-05-23', '15:13:18', '00:00:00', '', 0, 1, 'Online'),
(41, 1, '2021-05-23', '15:14:20', '15:45:00', 'wala', 0, 0, 'Offline'),
(42, 1, '2021-05-23', '15:45:55', '15:45:00', '', 0, 0, 'Offline'),
(43, 1, '2021-05-23', '15:46:34', '15:50:00', 's', 0, 0, 'Offline'),
(44, 1, '2021-05-24', '11:24:24', '11:41:00', 'asd', 0, 0, 'Offline'),
(45, 1, '2021-05-24', '11:42:02', '11:42:00', '', 0, 0, 'Offline'),
(46, 1, '2021-05-24', '11:43:55', '01:00:00', '', 0, 0, 'Offline'),
(47, 1, '2021-05-24', '11:47:03', '01:00:00', '', 0, 0, 'Offline'),
(48, 1, '2021-05-24', '11:49:16', '11:49:00', '', 0, 0, 'Offline'),
(49, 1, '2021-05-24', '11:50:08', '11:54:00', '', 0, 0, 'Offline'),
(50, 1, '2021-05-24', '11:56:05', '11:56:00', '', 0, 0, 'Offline'),
(51, 1, '2021-05-24', '12:05:16', '12:05:00', '', 0, 0, 'Offline'),
(52, 1, '2021-05-24', '12:05:20', '12:05:00', '', 0, 0, 'Offline'),
(53, 1, '2021-05-24', '12:33:01', '01:00:00', '', 0, 0, 'Offline'),
(54, 1, '2021-05-24', '12:39:08', '12:39:00', '', 0, 0, 'Offline'),
(55, 1, '2021-05-24', '13:56:44', '13:56:00', '', 0, 0, 'Offline'),
(56, 1, '2021-05-24', '14:15:37', '15:47:00', 'dota', 0, 0, 'Offline'),
(57, 1, '2021-05-24', '15:49:40', '16:52:00', 'we', 0, 0, ''),
(58, 1, '2021-05-24', '17:08:36', '17:09:00', '', 0, 0, 'Offline'),
(59, 1, '2021-05-24', '17:09:21', '17:15:00', '', 0, 0, ''),
(60, 1, '2021-05-24', '17:15:13', '17:15:00', '', 0, 0, ''),
(61, 1, '2021-05-24', '17:15:47', '18:08:00', 'wa', 0, 0, ''),
(62, 1, '2021-05-24', '18:11:37', '18:11:00', '', 0, 0, 'Offline'),
(63, 1, '2021-05-24', '18:11:51', '18:11:00', '', 0, 0, 'Offline'),
(64, 1, '2021-05-24', '18:12:59', '18:13:00', '', 0, 0, 'Offline'),
(65, 1, '2021-05-24', '18:13:15', '19:09:00', 'ewe', 0, 0, 'Offline'),
(66, 1, '2021-05-24', '19:09:41', '19:09:00', '', 0, 0, 'Offline');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1=Admin,2=Staff,3=Admin2',
  `company_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`, `company_id`) VALUES
(1, 'Warren D.C Inocencio', 'admin', '80ee7ece5bdf991bc2ae95776f02568d', 1, '7'),
(2, 'warren', 'warrena', '80ee7ece5bdf991bc2ae95776f02568d', 1, '0'),
(14, 's', 'wa', '80ee7ece5bdf991bc2ae95776f02568d', 1, '0'),
(18, 'warren', 'as22', '80ee7ece5bdf991bc2ae95776f02568d', 2, '7'),
(27, 'warren', 'asdasd', 'a8f5f167f44f4964e6c998dee827110c', 2, '0'),
(28, 'ino', 'asd', 'a8f5f167f44f4964e6c998dee827110c', 2, '0'),
(29, 'war', 'asd5', 'a8f5f167f44f4964e6c998dee827110c', 2, '0'),
(30, '123', '123', '4297f44b13955235245b2497399d7a93', 2, '0'),
(31, 'asdsad', 'asdsad5', 'a8f5f167f44f4964e6c998dee827110c', 2, '0'),
(32, 'war', 'asdsaddd', '4297f44b13955235245b2497399d7a93', 2, '1'),
(33, 'Jhemaima Ann Panget', 'admin2', '80ee7ece5bdf991bc2ae95776f02568d', 3, '8'),
(54, 'INOCENCIO, WARREN D.C', 'adsdwa', '80ee7ece5bdf991bc2ae95776f02568d', 2, '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `timesheets`
--
ALTER TABLE `timesheets`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
